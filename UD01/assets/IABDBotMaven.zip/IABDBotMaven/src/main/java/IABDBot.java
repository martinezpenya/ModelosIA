import dev.robocode.tankroyale.botapi.*;
import dev.robocode.tankroyale.botapi.events.*;

//Recuerda reemplazar (refactorizar) el nombre de IABDBot por tu nombre + dni,
//debes hacerlo también en el resto de ficheros de la carpeta.
public class IABDBot extends Bot {
    //Declaración de variables globales o constantes, se mantienen durante el combate.
    private double ultimoEnemigoVisto;
    private double direccionEnemigo;


    // Constructor, que carga el fichero de configuración
    IABDBot() {
        super(BotInfo.fromFile("src/main/java/IABDBot.json"));
    }

    // Este método inicializa nuestro Bot
    public static void main(String[] args) {
        new IABDBot().start();
    }

    public static double miMetodo(double angle) {
        //Métodos propios que podemos añadir.
        return 0;
    }

    @Override
    public void run() {
        //Se ejecuta en cada turno
        //¿Haremos ajustes con los bloqueos de cañon, radar y cuerpo?
        //¿Pondremos el radar a dar vueltas infinitas?

        //hacemos que el radar realice un escaneo completo
        rescan();

        // Evento personalizado
        addCustomEvent(new Condition("TooCloseToWalls") {
            public boolean test() {
                // El método test() es el que debemos reescribir para definir el resultado de nuestra condición.
                return (
                        // Aquí escribimos la condición que queremos comprobar.
                        (false || false)
                );
            }
        });
        while (isRunning()) {
            //aquí podemos llamar a métodos propios o de la clase Bot
            //doMove(); //para controlar el movimiento en un método aparte

            //o realizar los movimientos aquí mismo

            //Compara el funcionamiento de los dos bloques, comentando uno cada vez

//            //BLOQUE 1: Movimientos bloqueantes, hasta que no acaba uno, no empieza el siguiente
//            forward(100);
//            turnGunRight(180);
//            back(100);
//            turnGunLeft(180);

            //BLOQUE 2: Movimientos no bloqueantes, usando waitFor y condiciones (o go()).
            // Le decimos al robot que queremos avanzar 1000 unidades
            setForward(1000);
            // Le decimos también que queremos dar una vuelta completa al cañon
            setTurnGunRight(180);
            // En este punto le hemos dicho al robot que "queremos hacer algo"
            // queremos avanzar y girar el cañon. Eso es lo que significan los "set".
            // Es importante darse cuenta de que todavía no hemos hecho nada!
            // para comenzar a movernos, debemos llamar al método waitFor.
            // waitFor comienza la acción -- empezamos a movernos mientras giramos el cañon (todo a la vez).
            // Podemos crear nuestras propias condiciones, o llamar directamente a funciones lambda como en el siguiente ejemplo:
            waitFor(new Condition(() -> getGunTurnRemaining() == 0 || getDistanceRemaining() == 0));
            // El waitFor anterior espera a que se termine de avanzar o se termine de dar la vuelta al cañon, lo que pase antes.
            // Una vez alcanzada la condición, pedimos al Bot que vuelva para atrás y dé otra vuelta de cañon
            setBack(1000);
            setTurnGunLeft(180);
            // ... y volvemos a esperar ...
            waitFor(new Condition(() -> getGunTurnRemaining() == 0 || getDistanceRemaining() == 0));
            // Ahora volveremos al inicio del bucle.

            //¿Qué es mejor? Pues depende...

            //inicializa el movimiento de nuestro Bot lanzando las peticiones pendientes al server. Hasta que no llega aquí... no hace nada.
            go();
        }
    }

    //Este es un ejemplo de método que nos proporciona la API de Robocode, lo podemos sobreescribir para añadir nuestro código.
    @Override
    public void onScannedBot(ScannedBotEvent e) {
        // Cuando detectemos un enemigo...
        double angleToEnemy = radarBearingTo(e.getX(), e.getY());
        ultimoEnemigoVisto = bearingTo(e.getX(), e.getY());

    }

    // También podemos detectar cuando somos alcanzados por una bala
    @Override
    public void onHitByBullet(HitByBulletEvent e) {
        // ...
    }

    // También podemos detectar cuando un enemigo muere
    @Override
    public void onBotDeath(BotDeathEvent botDeathEvent) {
        // ...
    }

    public void onCustomEvent(CustomEvent e) {
        if (e.getCondition().getName().equals("TooCloseToWalls")) {
            // Aquí realizaremos las acciones que estimemos oportunas cuando se dispare el evento que hemos definido.
        }
    }
}