#!/bin/sh
java -cp ../lib/* IABDBot.java
